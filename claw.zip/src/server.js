const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const { exec } = require('child_process');
const { promisify } = require('util');
const ConfigManager = require('./config-manager');
const WizardClient = require('./wizard-client');

const execAsync = promisify(exec);

const app = express();
const PORT = process.env.PORT || 80;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const cssPath = path.join(__dirname, '..', 'public', 'styles.min.css');
const fsSync = require('fs');
if (fsSync.existsSync(cssPath)) {
  app.get('/styles.min.css', (req, res) => {
    res.sendFile(cssPath);
  });
}

const configManager = new ConfigManager();
const wizardClient = new WizardClient(configManager);

// Health check
app.get('/api/health', async (req, res) => {
  try {
    const status = await configManager.getOpenClawStatus();
    res.json({ status: 'ok', openclaw: status });
  } catch (error) {
    res.json({ status: 'ok', openclaw: 'not_configured' });
  }
});

// Check if OpenClaw is installed
app.get('/api/install/status', async (req, res) => {
  try {
    const { stdout } = await execAsync('openclaw --version');
    res.json({ installed: true, version: stdout.trim() });
  } catch {
    res.json({ installed: false });
  }
});

// Install OpenClaw
app.post('/api/install', async (req, res) => {
  try {
    const { stdout, stderr } = await execAsync('npm install -g openclaw');
    res.json({ success: true, output: stdout });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get current configuration
app.get('/api/config', async (req, res) => {
  try {
    const config = await configManager.getConfig();
    res.json({ success: true, config });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update configuration
app.post('/api/config', async (req, res) => {
  try {
    const { section, data } = req.body;
    await configManager.updateConfig(section, data);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Wizard endpoints
app.post('/api/wizard/start', async (req, res) => {
  try {
    const result = await wizardClient.startWizard();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/wizard/next', async (req, res) => {
  try {
    const result = await wizardClient.nextStep(req.body);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/wizard/cancel', async (req, res) => {
  try {
    await wizardClient.cancelWizard();
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/wizard/status', async (req, res) => {
  try {
    const status = await wizardClient.getWizardStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Model providers
app.get('/api/providers', async (req, res) => {
  try {
    const providers = await configManager.getProviders();
    res.json({ success: true, providers });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Set API key
app.post('/api/auth', async (req, res) => {
  try {
    const { provider, apiKey, model } = req.body;
    await configManager.setAuth(provider, apiKey, model);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Configure gateway
app.post('/api/gateway', async (req, res) => {
  try {
    const { port, bind, authMode, token, password } = req.body;
    await configManager.configureGateway({ port, bind, authMode, token, password });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Configure channels
app.post('/api/channels', async (req, res) => {
  try {
    const { channel, config } = req.body;
    await configManager.configureChannel(channel, config);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Configure web search
app.post('/api/web-search', async (req, res) => {
  try {
    const { provider, apiKey } = req.body;
    await configManager.configureWebSearch(provider, apiKey);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Configure workspace
app.post('/api/workspace', async (req, res) => {
  try {
    const { path: workspacePath } = req.body;
    await configManager.configureWorkspace(workspacePath);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Start OpenClaw gateway
app.post('/api/gateway/start', async (req, res) => {
  try {
    await configManager.startGateway();
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Stop OpenClaw gateway
app.post('/api/gateway/stop', async (req, res) => {
  try {
    await configManager.stopGateway();
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get gateway status
app.get('/api/gateway/status', async (req, res) => {
  try {
    const status = await configManager.getGatewayStatus();
    res.json({ success: true, status });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Health check
app.post('/api/health/check', async (req, res) => {
  try {
    const result = await configManager.runHealthCheck();
    res.json({ success: true, result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Install daemon
app.post('/api/daemon/install', async (req, res) => {
  try {
    const { runtime } = req.body;
    await configManager.installDaemon(runtime);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Install skills
app.post('/api/skills/install', async (req, res) => {
  try {
    const { nodeManager } = req.body;
    await configManager.installSkills(nodeManager);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get onboarding progress
app.get('/api/onboarding/progress', async (req, res) => {
  try {
    const progress = await configManager.getOnboardingProgress();
    res.json({ success: true, progress });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Complete onboarding
app.post('/api/onboarding/complete', async (req, res) => {
  try {
    await configManager.completeOnboarding();
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Reset configuration
app.post('/api/reset', async (req, res) => {
  try {
    const { scope } = req.body;
    await configManager.resetConfig(scope || 'config');
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get all available models
app.get('/api/models', async (req, res) => {
  try {
    const models = await configManager.getAvailableModels();
    res.json({ success: true, models });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Serve main page
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🍅 TomateCloud OpenClaw Wrapper rodando na porta ${PORT}`);
  console.log(`🌐 Acesse: http://localhost:${PORT}`);
});

module.exports = app;
